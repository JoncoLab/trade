<?php

/**
 * Created by PhpStorm.
 * User: Saladin
 * Date: 15.02.2017
 * Time: 18:38
 */
class Trade
{

}