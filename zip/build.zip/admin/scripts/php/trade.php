<?php

/**
 * Created by PhpStorm.
 * User: NeoNemo
 * Date: 16.01.2017
 * Time: 13:30
 */
//class Trade
//{
//    var $start_price;
//    var $step_done;
//    var $step_price;
//    var $final_price;
//    var $step_current = ($this->final_price - $this->start_price) / $this->step_price;
//
//}