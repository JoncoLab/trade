<?php
/**
 * Created by PhpStorm.
 * User: Saladin
 * Date: 03.04.2017
 * Time: 22:48
 */

$id = null;
$sellerName = null;
$type = null;
$gost = null;
$breed = null;
$characteristicsSort = null;
$characteristicsDiametr = null;
$characteristicsLength = null;
$characteristicsStorage = null;
$size = null;
$costStart = null;
$priceStart = null;
$step = null;
$costFinal = null;
$customerNumber = null;
$priceFinal = null;
$sellerId = null;
$customersApplied = null;
$guarantee = null;
$profit = null;

/**
 * В Екселі формат float'ів - "0.00", решти чисел - "0"
 */