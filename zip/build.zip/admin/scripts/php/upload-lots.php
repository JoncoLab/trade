<?php
/**
 * Created by PhpStorm.
 * User: Saladin
 * Date: 03.04.2017
 * Time: 22:48
 */

require_once "../../../scripts/php/PHPExcel/PHPExcel.php";

$id = null;
$sellerName = null;
$type = null;
$gost = null;
$breed = null;
$characteristicsSort = null;
$characteristicsDiametr = null;
$characteristicsLength = null;
$characteristicsStorage = null;
$size = null;
$costStart = null;
$priceStart = null;
$step = null;
$costFinal = null;
$customerNumber = null;
$priceFinal = null;
$sellerId = null;
$customersApplied = null;
$guarantee = null;
$profit = null;